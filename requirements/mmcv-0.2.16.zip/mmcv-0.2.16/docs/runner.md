## Runner

The runner module aims to help users to start training with less code, while stays
flexible and configurable.

Documentation and examples are still on going.